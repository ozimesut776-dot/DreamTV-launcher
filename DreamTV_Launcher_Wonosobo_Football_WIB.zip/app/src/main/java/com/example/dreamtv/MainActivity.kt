package com.example.dreamtv

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Calendar
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val apps = listOf(
        AppItem("YouTube", "com.google.android.youtube.tv", "▶", "#FFFFFF", "#E62117"),
        AppItem("Netflix", "com.netflix.ninja", "N", "#151515", "#E50914"),
        AppItem("Prime Video", "com.amazon.amazonvideo.livingroom", "prime", "#0759C7", "#FFFFFF"),
        AppItem("Spotify", "com.spotify.tv.android", "♫", "#10251F", "#1ED760"),
        AppItem("Play Store", "com.android.vending", "▶", "#162B4C", "#75D7FF"),
        AppItem("Pengaturan", "com.android.tv.settings", "⚙", "#263B60", "#FFFFFF")
    )
    private val handler = Handler(Looper.getMainLooper())
    private var rootView: LinearLayout? = null
    private var clockView: TextView? = null
    private var dateView: TextView? = null
    private var weatherView: TextView? = null
    private var footballView: TextView? = null
    private var weatherCode: Int = 1
    private var temperature: Int? = null
    private var weatherText = "Mengambil informasi cuaca…"
    // Default lokasi Wonosobo; ubah koordinat ini jika ingin kota lain.
    private val latitude = -7.36
    private val longitude = 109.90

    private val ticker = object : Runnable {
        override fun run() {
            val now = Date()
            clockView?.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            dateView?.text = SimpleDateFormat("EEEE, dd MMMM", Locale("id", "ID")).format(now)
            updateBackground()
            handler.postDelayed(this, 30_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        buildHome()
        handler.post(ticker)
        fetchWeather()
        fetchFootballSchedule()
        handler.postDelayed(object : Runnable {
            override fun run() { fetchFootballSchedule(); handler.postDelayed(this, 30 * 60 * 1000L) }
        }, 30 * 60 * 1000L)
        handler.postDelayed(object : Runnable {
            override fun run() { fetchWeather(); handler.postDelayed(this, 30 * 60 * 1000L) }
        }, 30 * 60 * 1000L)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun buildHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(42), dp(25), dp(42), dp(22))
        }
        rootView = root
        setContentView(root)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        dateView = TextView(this).apply {
            text = SimpleDateFormat("EEEE, dd MMMM", Locale("id", "ID")).format(Date())
            setTextColor(Color.WHITE); textSize = 20f
        }
        top.addView(dateView, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(infoPill("● Wi-Fi"), LinearLayout.LayoutParams(-2, -2))
        top.addView(space(12))
        top.addView(infoPill("⚙"), LinearLayout.LayoutParams(-2, -2))
        root.addView(top)

        clockView = TextView(this).apply {
            text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            setTextColor(Color.WHITE); textSize = 66f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(clockView)
        weatherView = TextView(this).apply {
            text = "☁   $weatherText"
            setTextColor(Color.WHITE); textSize = 17f
        }
        root.addView(weatherView)

        val prayerRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(22), 0, dp(12)) }
        listOf("Subuh\n04:30", "Dzuhur\n11:45", "Ashar\n14:55", "Maghrib\n17:40", "Isya\n18:50").forEach {
            val tile = TextView(this).apply {
                text = it; gravity = Gravity.CENTER; textSize = 14f; setTextColor(Color.WHITE)
                background = rounded(Color.argb(45,255,255,255), Color.argb(110,255,255,255), 18)
                setPadding(dp(14), dp(8), dp(14), dp(8))
            }
            val lp = LinearLayout.LayoutParams(0, dp(58), 1f); lp.setMargins(0, 0, dp(8), 0)
            prayerRow.addView(tile, lp)
        }
        root.addView(prayerRow)

        footballView = TextView(this).apply {
            text = "⚽  JADWAL SEPAK BOLA (WIB)\nMengambil jadwal pertandingan…"
            setTextColor(Color.WHITE); textSize = 15f
            background = rounded(Color.argb(48, 8, 24, 60), Color.argb(100,255,255,255), 18)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            maxLines = 3
        }
        root.addView(footballView, LinearLayout.LayoutParams(-1, dp(88)))
        root.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(TextView(this).apply {
            text = "APLIKASI FAVORIT"; setTextColor(Color.argb(220,255,255,255)); textSize = 12f
            setPadding(dp(4), 0, 0, dp(8))
        })
        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = rounded(Color.argb(210, 9, 31, 82), Color.argb(130,255,255,255), 26)
        }
        apps.forEachIndexed { index, app ->
            val tile = TextView(this).apply {
                text = "${app.symbol}\n${app.name}"; gravity = Gravity.CENTER; textSize = 15f
                typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor(app.foreground))
                background = rounded(Color.parseColor(app.background), if (index == 0) Color.WHITE else Color.argb(80,255,255,255), 18)
                isFocusable = true; isFocusableInTouchMode = true
                setPadding(dp(8), dp(10), dp(8), dp(10))
                setOnFocusChangeListener { v, focused ->
                    v.background = rounded(Color.parseColor(app.background), if (focused) Color.rgb(91,197,255) else Color.argb(80,255,255,255), if (focused) 22 else 18)
                    v.scaleX = if (focused) 1.06f else 1f; v.scaleY = if (focused) 1.06f else 1f
                }
                setOnClickListener { launchApp(app.packageName, app.name) }
            }
            val lp = LinearLayout.LayoutParams(0, dp(82), 1f); lp.setMargins(dp(5), 0, dp(5), 0)
            dock.addView(tile, lp)
        }
        root.addView(dock)
        updateBackground()
        dock.getChildAt(0)?.requestFocus()
    }

    private fun fetchWeather() {
        thread {
            var conn: HttpURLConnection? = null
            try {
                val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$latitude&longitude=$longitude&current=temperature_2m,weather_code,is_day&timezone=Asia%2FJakarta")
                conn = (url.openConnection() as HttpURLConnection).apply { connectTimeout = 8000; readTimeout = 8000; requestMethod = "GET" }
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val current = JSONObject(body).getJSONObject("current")
                val code = current.getInt("weather_code")
                val temp = current.getDouble("temperature_2m").toInt()
                runOnUiThread {
                    weatherCode = code; temperature = temp
                    weatherText = "${weatherEmoji(code)}  ${weatherDescription(code)} • ${temp}°C • Wonosobo"
                    weatherView?.text = weatherText
                    updateBackground()
                }
            } catch (_: Exception) {
                runOnUiThread {
                    weatherText = "Cuaca tidak tersedia • periksa koneksi internet"
                    weatherView?.text = "☁   $weatherText"
                    updateBackground()
                }
            } finally { conn?.disconnect() }
        }
    }

    private fun fetchFootballSchedule() {
        thread {
            val leagues = listOf(
                "eng.1" to "Premier League",
                "esp.1" to "La Liga",
                "uefa.champions" to "Liga Champions"
            )
            val matches = mutableListOf<Triple<Long, String, String>>()
            for ((leagueId, leagueName) in leagues) {
                var conn: HttpURLConnection? = null
                try {
                    val dateFormat = SimpleDateFormat("yyyyMMdd", Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("Asia/Jakarta") }
                    val startDate = dateFormat.format(Date())
                    val endCalendar = Calendar.getInstance(java.util.TimeZone.getTimeZone("Asia/Jakarta")).apply { add(Calendar.DAY_OF_YEAR, 7) }
                    val endDate = dateFormat.format(endCalendar.time)
                    val url = URL("https://site.api.espn.com/apis/site/v2/sports/soccer/$leagueId/scoreboard?dates=$startDate-$endDate&limit=100")
                    conn = (url.openConnection() as HttpURLConnection).apply {
                        connectTimeout = 7000; readTimeout = 7000; requestMethod = "GET"
                        setRequestProperty("User-Agent", "DreamTVLauncher/1.0")
                    }
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    val events = JSONObject(body).optJSONArray("events") ?: continue
                    for (i in 0 until events.length()) {
                        val event = events.optJSONObject(i) ?: continue
                        val dateText = event.optString("date", "")
                        val epoch = try { SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX", Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }.parse(dateText)?.time ?: continue } catch (_: Exception) { continue }
                        val comp = event.optJSONArray("competitions")?.optJSONObject(0) ?: continue
                        val competitors = comp.optJSONArray("competitors") ?: continue
                        if (competitors.length() < 2) continue
                        val first = competitors.optJSONObject(0)?.optJSONObject("team")?.optString("displayName", "") ?: ""
                        val second = competitors.optJSONObject(1)?.optJSONObject("team")?.optString("displayName", "") ?: ""
                        val status = comp.optJSONObject("status")?.optJSONObject("type")?.optString("shortDetail", "") ?: ""
                        val fmt = SimpleDateFormat("EEE dd/MM HH:mm", Locale("id", "ID")).apply { timeZone = java.util.TimeZone.getTimeZone("Asia/Jakarta") }
                        val line = "${fmt.format(Date(epoch))} WIB  $first vs $second  ·  $leagueName"
                        matches.add(Triple(epoch, line, status))
                    }
                } catch (_: Exception) {
                    // One league can fail independently; keep any schedules already retrieved.
                } finally { conn?.disconnect() }
            }
            val now = System.currentTimeMillis()
            val upcoming = matches.distinctBy { it.second }.filter { it.first >= now - 2 * 60 * 60 * 1000L }.sortedBy { it.first }.take(2)
            val display = when {
                upcoming.isNotEmpty() -> "⚽  JADWAL SEPAK BOLA (WIB)\n" + upcoming.joinToString("\n") { it.second }
                matches.isNotEmpty() -> "⚽  JADWAL SEPAK BOLA (WIB)\nJadwal mendatang belum tersedia saat ini"
                else -> "⚽  JADWAL SEPAK BOLA (WIB)\nJadwal belum tersedia • periksa koneksi internet"
            }
            runOnUiThread { footballView?.text = display }
        }
    }

    private fun updateBackground() {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val isNight = hour < 5 || hour >= 19
        val isDawn = hour in 5..6
        val isEvening = hour in 17..18
        val cloudy = weatherCode in listOf(2, 3, 45, 48)
        val rainy = weatherCode in 51..67 || weatherCode in 80..82 || weatherCode in 95..99
        val colors = when {
            rainy -> intArrayOf(Color.rgb(34,48,68), Color.rgb(65,82,105), Color.rgb(18,27,46))
            cloudy -> if (isNight) intArrayOf(Color.rgb(20,29,53), Color.rgb(57,67,91), Color.rgb(13,19,39)) else intArrayOf(Color.rgb(83,105,132), Color.rgb(121,143,164), Color.rgb(43,61,88))
            isNight -> intArrayOf(Color.rgb(5,12,38), Color.rgb(24,37,78), Color.rgb(8,16,47))
            isDawn -> intArrayOf(Color.rgb(83,103,169), Color.rgb(242,151,120), Color.rgb(56,71,129))
            isEvening -> intArrayOf(Color.rgb(247,139,91), Color.rgb(119,88,151), Color.rgb(34,43,91))
            else -> intArrayOf(Color.rgb(35,116,210), Color.rgb(95,169,232), Color.rgb(25,62,135))
        }
        rootView?.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors)
    }

    private fun weatherDescription(code: Int): String = when (code) {
        0 -> "Cerah"; 1 -> "Cerah berawan"; 2 -> "Berawan sebagian"; 3 -> "Berawan"
        45, 48 -> "Berkabut"; in 51..57 -> "Gerimis"; in 61..67 -> "Hujan"
        in 71..77 -> "Salju"; in 80..82 -> "Hujan lokal"; 85, 86 -> "Hujan salju"
        in 95..99 -> "Badai petir"; else -> "Kondisi cuaca berubah"
    }
    private fun weatherEmoji(code: Int): String = when (code) {
        0 -> "☀"; 1, 2 -> "🌤"; 3 -> "☁"; 45, 48 -> "🌫"
        in 51..67 -> "🌧"; in 71..77 -> "❄"; in 80..82 -> "🌦"; in 95..99 -> "⛈"; else -> "🌥"
    }

    private fun launchApp(packageName: String, label: String) {
        try {
            val intent = packageManager.getLeanbackLaunchIntentForPackage(packageName) ?: packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) startActivity(intent) else Toast.makeText(this, "$label belum terpasang di TV", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) { Toast.makeText(this, "Tidak dapat membuka $label", Toast.LENGTH_SHORT).show() }
    }
    private fun infoPill(text: String) = TextView(this).apply {
        this.text = text; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        background = rounded(Color.argb(50,255,255,255), Color.argb(80,255,255,255), 50)
        setPadding(dp(12), dp(8), dp(12), dp(8))
    }
    private fun space(w: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(w), 1) }
    private fun rounded(color: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), stroke)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    data class AppItem(val name: String, val packageName: String, val symbol: String, val background: String, val foreground: String)
}
