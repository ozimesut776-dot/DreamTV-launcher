# DreamTV Launcher — Dynamic Weather + Football Schedule

Android TV launcher project designed for landscape screens. The weather location is fixed to Wonosobo, Indonesia (latitude -7.36, longitude 109.90). Current weather is fetched from Open-Meteo and the background gradient changes with local time and weather conditions.

## Added in this version
- Wonosobo weather remains the fixed location.
- Background colors adapt to local time (dawn, day, evening, night) and reported weather (clear, cloudy, rain, storm).
- Football schedule section uses ESPN's public scoreboard endpoints for Premier League, La Liga and UEFA Champions League.
- Match kickoff times are converted to Asia/Jakarta (WIB).
- Weather and football schedules refresh about every 30 minutes. Internet access is needed for live data; if the schedule API is unavailable, the UI shows a fallback message.

## Build
Open this project in Android Studio or upload its contents to a GitHub repository and run the included GitHub Actions workflow (`.github/workflows/android-build.yml`). The workflow should produce a debug APK artifact. This source project has not been compiled or tested on a physical Changhong TV, so verify the build and test before setting it as the default launcher.
